/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Appointment;
import Model.Patient;
import Model.VaccinationCenter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author raniacharkaoui
 */
public class AppointmentController implements Serializable{
    

    public AppointmentController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }
    public void create(Appointment appointment) {
       
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            
            Patient patient = appointment.getPatient();
            if (patient != null) {
                patient = em.getReference(patient.getClass(), patient.getId());
                appointment.setPatient(patient);
            }
            VaccinationCenter center = appointment.getVaccinationCenter();
            if (center != null) {
                center = em.getReference(center.getClass(), center.getId());
                appointment.setVaccinationCenter(center);
            }
            em.persist(appointment);
           
            if (patient != null) {
                patient.getAppointmentCollection().add(appointment);
                patient = em.merge(patient);
            }
            if (center != null) {
                center.getAppointmentCollection().add(appointment);
                center = em.merge(center);
            }
           
            
            em.getTransaction().commit();
            System.out.println("Create ok");
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
}
     