/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Appointment;
import Model.Patient;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author raniacharkaoui
 */
public class AppointmentController implements Serializable{
    

    public AppointmentController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }
    public void create(Appointment appointment) {
       
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            
//            Patient idpatient = appointment.getId();
//            if (idpatient != null) {
//                idpatient = em.getReference(idpatient.getClass(), idpatient.getId());
//                appointment.setId(idpatient);
//            }
//            
//            if (idpatient != null) {
//                idpatient.getAppointmentList().add(appointment);
//                idpatient = em.merge(idpatient);
//            }
            
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
}
     