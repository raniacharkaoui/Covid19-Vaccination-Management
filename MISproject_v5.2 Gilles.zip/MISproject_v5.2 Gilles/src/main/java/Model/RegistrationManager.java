/**
 *
 * @author raniacharkaoui
 */
package Model;

import java.util.ArrayList;


public class RegistrationManager {
    private ArrayList<VaccinationCenter> centers = new ArrayList<VaccinationCenter>();
    
    
    public RegistrationManager(){
}
    
    
}
// fct : attribuer le bon centre aux bonnes personnes 
// ajouter appointment dans la list du vaccinationcenter concerné si dispo temps et dose il faut un agenda 
