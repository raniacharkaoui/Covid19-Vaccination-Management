/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Appointment;
import Model.Patient;
import Model.WaitingList;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author raniacharkaoui
 */
public class WaitingListController implements Serializable{
    public WaitingListController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }
    public void create(WaitingList list) {

//        if (patient.getAppointmentList() == null) {
//            patient.setAppointmentList(new ArrayList<Appointment>());
//        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(list);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
// code à ajouter somewhere où on va créer et update la liste
//    WaitingList list = null; 
//    Patient patient; 
//    public void updateList(){
//        if( list == null ){
//            list = new WaitingList(); 
//            System.out.println("New patient in List created");
//            System.out.println(list.getId());
//        }
//        
//        
//        list.setPatient(patient);
//        list.setVaccinationCenter(patient.getClosestCenter());
//        System.out.println("Patient added in waiting list");
//        
//    }
    public Patient sortPatient(){
        // uses Query WaitingList.sort to sort Patient 
        // by their score in descending
        EntityManager em = getEntityManager();
        List<Patient> results = em.createNamedQuery("WaitingList.sort").getResultList();
        
        if( results.size() > 0 ){
            return results.get(0);
        }
        else
            return null;
    }
    //Patient patientToCall = sortPatient();
    public void callPatient(Patient p) throws MessagingException{
        // Sends email to patient p 
        // to call him/her at a vaccination center
        // and creates appointment
        String address = p.getEmail();
        String subject = "Votre rendez-vous de vaccination";
        String message = "Bonjour\n"
                + "Votre vaccin est réservé et vous attend.";
        SendingEmail mail = new SendingEmail();
        mail.sendEmail(address, subject, message);
        Appointment a= new Appointment();
        a.setVaccinationCenter(p.getClosestCenter());
        a.setPatient(p);
        a.setAppointmentTime(new Date());
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("MISproject2_PU");
        AppointmentController ctrl = new AppointmentController(emf);
        ctrl.create(a);
    }
}
