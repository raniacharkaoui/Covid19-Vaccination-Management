/**
 *
 * @author raniacharkaoui
 */
package Model;

import java.util.ArrayList;


public class RegistrationManager {
    
    private VaccinationCenter  center1 = new VaccinationCenter(); 
    private VaccinationCenter  center2 = new VaccinationCenter(); 
    private VaccinationCenter  center3 = new VaccinationCenter(); 
    private VaccinationCenter  center4 = new VaccinationCenter(); 
    
    public RegistrationManager(){
}
    
    
}
// centre 1 : patiient 1 et 2 (closestCenter==1)
// places dispo => update la collection patient de l'objet center 1 
// collection<Patient> 1 = liste d'attente du centre 1 
// à 17h il récupère availableDoses -> envoie les mails aux X premières personnes 
// calcul de score et attribution (setscore)
// liste ordonnée en fonction des scores 

// fct : attribuer le bon centre aux bonnes personnes 
// ajouter appointment dans la list du vaccinationcenter concerné si dispo temps et dose il faut un agenda 
// tous les patients avec closestCenter == vaccinationCenter sont dedans 
// quand y'a des doses dispo -> on appelle les prioritaires 