/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author raniacharkaoui
 */
public class SendingEmail {
    public void sendEmail(String toAddress,
        String subject, String message) throws AddressException,
        MessagingException {

        final String username = "vaccination.management@gmail.com";
        final String password = "2021covid";

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true"); //TLS
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress("vaccination.management@gmail.com"));
            msg.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(toAddress)
            );
            msg.setSubject(subject);
            msg.setText("message"
                    + "\n\n Vous êtes invités à vous rendre au centre de vaccination suivant :");

            Transport.send(msg);

            System.out.println("Email successfully sent");
        } catch (MessagingException e) {
            e.printStackTrace();
        }

}
}
