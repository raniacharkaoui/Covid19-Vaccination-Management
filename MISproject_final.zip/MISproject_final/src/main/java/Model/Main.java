
package Model;



import View.MainWindow;



/**
 *
 * @author raniacharkaoui
 */
public class Main {
    
    public static void main(String args[]) {

 
        new MainWindow().setVisible(true);
    }
       
    }
    
    

